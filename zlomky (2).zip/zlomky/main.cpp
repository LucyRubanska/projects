#include <iostream>
#include "zlomky.h"
#include <bits/stdc++.h>


//treba osetrit zaporne cisla, takisto ked rovnake zlomky tak nech to zisti (==)




int main()
{
    Zlomok Zlomok1;
    Zlomok Zlomok2 (4,3);
    Zlomok Zlomok3 = Zlomok1+Zlomok2;
    std::cout << Zlomok1/Zlomok2 << std::endl;
   // std::cout << Zlomok3 << std::endl;

    return 0;



}

Zlomok::Zlomok()
{
    std::cout << "Zadaj citatel a menovatel: " << std::flush;
    std::cin >> citatel >> menovatel;
    reduceFraction();
}

Zlomok::Zlomok(int mojCit, int mojMen):citatel(mojCit),menovatel(mojMen)
{
    reduceFraction();
}

Zlomok::Zlomok(char typ, int castzlomku)
{
    switch(typ)
    {

        case 'c':
        {
            citatel=castzlomku;
            menovatel=1;
            //std::cin>>menovatel;
            break;
        }
        case 'm':
        {
            menovatel=castzlomku;
            std::cout<<"Zadaj citatel " << std::endl;
            std::cin>>menovatel;
            break;
        }
        default:
        {
            citatel = 0;
            menovatel = 1;
            std::cout<< "Zadal si cislo 0" <<std::endl;
            break;
        }
    }

}



float Zlomok::getFloat(bool noZero)
{
    float tmp;
    while (true)
    {
        try
        {
            std::cout << "Zadaj cele cislo: ";
            if (!(std::cin >> tmp))
            {
                throw Zlomok::noNumber("Nebolo zadane cislo. ");
            }
            if (noZero and tmp == 0)
            {
                throw Zlomok::noZero("Cislo je nula. Zadaj dalsie cislo: ");
            }

        }
        catch (const noNumber &ex)
        {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            ex.getMsg();
            continue;
        }
        return tmp;
    }
}


bool Zlomok::operator>(const Zlomok & druhyZlomok) const
{
    float hodnota1, hodnota2;
    hodnota1=citatel/menovatel;
    hodnota2=druhyZlomok.citatel/druhyZlomok.menovatel;
    return hodnota1 > hodnota2;
}

bool Zlomok::operator<(const Zlomok & druhyZlomok) const //nevadi tam to const?? a takisto z int na float
{
    float hodnota1, hodnota2;
    hodnota1=citatel/menovatel;
    hodnota2=druhyZlomok.citatel/druhyZlomok.menovatel;
    return hodnota2 > hodnota1;
}

Zlomok Zlomok::operator+(const Zlomok & inyZlomok) const
{
    return {(citatel*inyZlomok.menovatel)+(inyZlomok.citatel*menovatel), menovatel*inyZlomok.menovatel};
}

Zlomok Zlomok::operator-(const Zlomok & inyZlomok) const
{
   return {(citatel*inyZlomok.menovatel)-(inyZlomok.citatel*menovatel), menovatel*inyZlomok.menovatel};
}

Zlomok Zlomok::operator*(const Zlomok & inyZlomok) const
{
    return {citatel*inyZlomok.citatel, menovatel*inyZlomok.menovatel};
}

Zlomok Zlomok::operator/(const Zlomok & inyZlomok) const
{
    return {citatel*inyZlomok.menovatel, menovatel*inyZlomok.citatel};
}

std::istream & operator>>(std::istream & is, Zlomok & zlomok)
{
        std::cout << "Zadaj citatel zlomku: " << std::endl;
        is>>zlomok.citatel;
        std::cout << "Zadaj menovatel zlomku: " << std::endl;
        is>>zlomok.menovatel;

        return is;
}

std::ostream & operator<<(std::ostream & os, const Zlomok & zlomok)
{
    os << zlomok.citatel << "/" << zlomok.menovatel<<std::endl;
    return os;
}

void Zlomok::reduceFraction()
{
    using namespace std;

    int d;
    d = __gcd(citatel,menovatel);

    citatel = citatel / d;
    menovatel = menovatel / d;
    cout << citatel<< "/" << menovatel << endl;
    //return {citatel,menovatel};
}

//vynimky
void Zlomok::noNumber::getMsg() const
{
    std::cout << msg << std::endl;
}

void Zlomok::noZero::getMsg1() const
{
    std::cout << msg1 << std::endl;
}

