#include <iostream>
#include "zlomky.h"
#include <bits/stdc++.h>


//treba osetrit zaporne cisla, takisto ked rovnake zlomky tak nech to zisti (==)
// treba aj pri operaciach so zlomkami asi upravit na zakladny tvar




int main()
{
    Zlomok Zlomok1(4,6);
    Zlomok Zlomok2;
    Zlomok Zlomok3 = Zlomok1+Zlomok2;
    std::cout << Zlomok1+Zlomok2 << std::endl;
    std::cout << Zlomok3 << std::endl;

    return 0;



}

Zlomok::Zlomok()
{
    std::cout << "Zadaj citatel a menovatel: " << std::flush;
    std::cin >> citatel >> menovatel;
    reduceFraction();
}

Zlomok::Zlomok(int mojCit, int mojMen):citatel(mojCit),menovatel(mojMen)
{
    reduceFraction();
}

Zlomok::Zlomok(char typ, int castzlomku)
{
    switch(typ)
    {

        case 'c':
        {
            citatel=castzlomku;
            menovatel=1;
            //std::cin>>menovatel;
            break;
        }
        case 'm':
        {
            menovatel=castzlomku;
            std::cout<<"Zadaj citatel " << std::endl;
            std::cin>>menovatel;
            break;
        }
        default:
        {
            citatel = 0;
            menovatel = 1;
            std::cout<< "Zadal si cislo 0" <<std::endl;
            break;
        }
    }

}



float Zlomok::getFloat(bool noZero)
{
    float tmp;
    while (true)
    {
        try
        {
            std::cout << "Zadaj cele cislo: ";
            if (!(std::cin >> tmp))
            {
                throw Zlomok::noNumber("Nebolo zadane cislo. ");
            }
            if (noZero == true and tmp == 0)
            {
                throw Zlomok::noZero("Cislo je nula. Zadaj dalsie cislo: ");
            }

        }
        catch (const noNumber &ex)
        {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            ex.getMsg();
            continue;
        }
        return tmp;
    }
}

//metody
Zlomok* Zlomok::spolMenovatel(const Zlomok &zlomok1, const Zlomok &zlomok2) //vkladas konstanty objekt (const const Zlomok &zlomek1); a vracas konstantny objekt const
{
    Zlomok arr[2] = {Zlomok(zlomok1.citatel*zlomok2.menovatel, zlomok1.menovatel*zlomok2.menovatel),Zlomok( zlomok2.citatel * zlomok1.menovatel, zlomok1.menovatel*zlomok2.menovatel)};

    return arr;

}

//operatoryyyyy

bool Zlomok::operator>(const Zlomok & druhyZlomok) const
{
    spolMenovatel();
    return {citatel > druhyZlomok.citatel, druhyZlomok. menovatel};
}

bool Zlomok::operator<(const Zlomok & druhyZlomok) const
{
    spolMenovatel();
    return {citatel < druhyZlomok.citatel, druhyZlomok.menovatel};//neco neni zle
}

Zlomok Zlomok::operator+(const Zlomok & inyZlomok) const
{
    spolMenovatel();
    return {citatel+inyZlomok.citatel, inyZlomok.menovatel};
}

Zlomok Zlomok::operator-(const Zlomok & inyZlomok) const
{
    spolMenovatel();
   return {citatel-inyZlomok.citatel, inyZlomok.menovatel};
}

Zlomok Zlomok::operator*(const Zlomok & inyZlomok) const
{
    return {citatel*inyZlomok.citatel, menovatel*inyZlomok.menovatel};
}

Zlomok Zlomok::operator/(const Zlomok & inyZlomok) const
{
    return {citatel*inyZlomok.menovatel, menovatel*inyZlomok.citatel};
}

std::istream & operator>>(std::istream & is, Zlomok & zlomok) //nieco je zle
{
        std::cout << "Zadaj citatel zlomku: " << std::endl; //treba to??
        is>>zlomok.citatel;
        std::cout << "Zadaj menovatel zlomku: " << std::endl;
        is>>zlomok.menovatel;

        return is;
}

std::ostream & operator<<(std::ostream & os, const Zlomok & zlomok)
{
    os << zlomok.citatel << "/" << zlomok.menovatel<<std::endl; //nieco je zle
    return os;
}

//uprava na zakladny tvar zlomku
Zlomok Zlomok::reduceFraction()
{
    using namespace std;

    int d;
    d = __gcd(citatel,menovatel);

    citatel = citatel / d;
    menovatel = menovatel / d;
    cout << citatel<< "/" << menovatel << endl;
    return {citatel,menovatel};
}

//vynimky
void Zlomok::noNumber::getMsg() const
{
    std::cout << msg << std::endl;
}

void Zlomok::noZero::getMsg1() const
{
    std::cout << msg1 << std::endl;
}

