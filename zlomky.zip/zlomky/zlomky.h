//
// Created by avar on 26. 1. 2021.
//

#ifndef ZLOMKY_ZLOMKY_H
#define ZLOMKY_ZLOMKY_H

class Zlomok
{
private:

    int  citatel;  // mozno dam proste float, ked tomu zacne jebat
    int  menovatel;

public:

    Zlomok();
    Zlomok(int mojCit, int mojMen);
    Zlomok(char typ, int castzlomku);

    Zlomok reduceFraction();
    static float getFloat(bool noZero = false);

    friend std::ostream & operator<<(std::ostream & os, const Zlomok & zlomok); //friend sa nepise pri implementacii ani menny priestor
    friend std::istream & operator>>(std::istream & is, Zlomok & zlomok);

    bool operator>(const Zlomok & druhyZlomok) const;
    bool operator<(const Zlomok & druhyZlomok) const;
    Zlomok operator+(const Zlomok & inyZlomok) const;
    Zlomok operator-(const Zlomok &inyZlomok) const;
    Zlomok operator/(const Zlomok & inyZlomok) const;//neviem ci tam musi byt friend
    Zlomok operator*(const Zlomok & inyZlomok) const; //neviem ci tam musi byt friend

    static Zlomok* spolMenovatel(const Zlomok &zlomok1, const Zlomok & zlomok2);

    class noZero
    {
    private:
        const char * msg1;
    public:
        noZero(const char * sprava1):msg1(sprava1){};
        void getMsg1() const;
    };

    class noNumber
    {
    private:
        const char * msg;
    public:
        noNumber(const char * sprava):msg(sprava){};
        void getMsg() const;
    };



};

#endif //ZLOMKY_ZLOMKY_H
